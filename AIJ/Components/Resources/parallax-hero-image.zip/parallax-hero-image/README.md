Parallax Hero Image
=========

A full-width figure element, with floating images distributed in a 3D space.

[Article on CodyHouse](http://codyhouse.co/gem/parallax-hero-image/)

[Demo](http://codyhouse.co/demo/parallax-hero-image/index.html)

Image credits: [Unsplash](https://unsplash.com/) and [Subtlepatterns](http://subtlepatterns.com/)
 
[Terms](http://codyhouse.co/terms/)
