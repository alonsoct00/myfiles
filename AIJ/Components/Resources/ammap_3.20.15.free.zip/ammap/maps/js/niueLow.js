// (c) ammap.com | SVG (in JSON format) map of Niue - Low
// areas: {id:"NU"}
AmCharts.maps.niueLow={
	"svg": {
		"defs": {
			"amcharts:ammap": {
				"projection":"mercator",
				"leftLongitude":"-169.7743249",
				"topLatitude":"-18.9526261",
				"rightLongitude":"-169.9497923",
				"bottomLatitude":"-19.1554807"
			}
		},
		"g":{
			"path":[
				{
					"id":"NU",
					"title":"Niue",
					"d":"M246.18,896.56L799.55,523.94L597.3,14.37L474.05,0L260.93,0L80.22,244.68L115.74,365.41L0.45,616.77L126.22,677.57L80.22,830.41L246.18,896.56z"
				}
			]
		}
	}
};
